
<?php $__env->startSection('title'); ?>
    Selamat Datang di Magersari
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="welcome">
        <img src="<?php echo e(asset('assets/fe/img/logo.png')); ?>" alt="">
        <h1 data-aos="fade-up">Paguyuban Magersari</h1>
        <p data-aos="fade-down">
            Hasil product tanaman hias oleh para masyarakat paguyuran magersari, Kab Magelang, Jawa Tengah
        </p>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="product">
                <div class="row justify-content-center">
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6">
                            <a href="<?php echo e(route('magersari.detail', $item->slug)); ?>">
                                <div class="card" data-aos="flip-up">
                                    <img src="<?php echo e(asset('img/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>">
                                    <h3><?php echo e($item->title); ?></h3>
                                    <div class="detail">
                                        <div class="d-flex justify-content-between">
                                            <p>Rp. <?php echo e(number_format($item->harga)); ?></p>
                                            <p><?php echo e($item->stock); ?> Stock</p>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-lg">

                        </div>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <?php echo $data->links(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.mitra.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipentas\pengmas\resources\views/mitra/magersari/index.blade.php ENDPATH**/ ?>