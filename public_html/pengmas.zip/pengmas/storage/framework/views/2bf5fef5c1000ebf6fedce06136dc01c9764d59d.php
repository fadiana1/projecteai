<?php $__env->startSection('title'); ?>
Keranjang Belanja Anda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <section class="cart">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card rounded-15 p-3">
                        <img src="<?php echo e(asset('img/' . $data->image)); ?>" class="img-fluid rounded-15" alt="">
                        <h2><?php echo e($data->title); ?></h2>

                         <!-- <div class="d-flex justify-content-center mt-3">
                            <button type="button" class="btn btn-primary kurang"><i class="fas fa-minus"></i></button>
                            <input type="number" min="1" readonly class="form-control text-center me-3 ms-3"
                                value="1" name="jumlah" id="jumlah">
                            <button type="button" class="btn btn-primary tambah"><i class="fas fa-plus"></i></button>
                        </div>
                        <div class="d-flex justify-content-between mt-4">
                            <p class="text-muted">Sub Total</p>
                            <p class="fw-bold" id="sub-text">Rp <?php echo e(number_format($data->harga)); ?></p>

                            <?php if(session('success')): ?>
                            <?php
                            $potongan = (intval($data->harga) * session('potongan')) / 100;
                            $sub_total = intval($data->harga) - intval($potongan);
                            ?>
                            <input type="number" id="subtotal" value="<?php echo e($sub_total); ?>" hidden>
                            <?php else: ?>
                            <input type="number" id="subtotal" value="<?php echo e($data->harga); ?>" hidden>
                            <?php endif; ?>
                        </div> -->

			<!--disini nambah "<?php echo e(number_format($data->harga)); ?>"-->
                        <div class="d-flex justify-content-between">
                            <h4 class="fw-bold">Total</h4>
                            <p class="fw-bold" id="total-text">Rp <?php echo e(number_format($data->harga)); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Pesanan</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($data->title); ?></li>
                        </ol>
                    </nav>

                    <div class="card p-3 rounded-15">
                        <h3 class="fw-bold mb-3 text-center">Rincian Pembayaran</h3>
                        <form action="<?php echo e(route('payment')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <td>Nama Lengkap</td>
                                        <td>:</td>
                                        <td>
                                            <input type="text"
                                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                                placeholder="Full Name" autocomplete="off">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Nomor Telepon</td>
                                        <td>:</td>
                                        <td>
                                            <input type="phone"
                                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                                                placeholder="Eg 0819xxx" autocomplete="off">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Item Pesanan</td>
                                        <td>:</td>
                                        <td><?php echo e($data->title); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pengiriman</td>
                                        <td>:</td>
                                        <td>
                                            <select class="form-select <?php $__errorArgs = ['pengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="pengiriman" id="pengiriman" aria-label="Default select example">
                                                <option value="">-- Pilih --</option>
                                                <option value="cod">Cast On Delivery</option>
                                                <option value="ekspedisi">Ekspedisi</option>
                                            </select>
                                            <?php $__errorArgs = ['pengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                    </tr>
					
					<!--// nambah id="jumlah"-->
                                    <tr>
                                        <td>Jumlah Pesanan</td>
                                        <td>:</td>
                                        <td>
                                            <input name="jumlah" type="number" id="jumlah" class="form-control  <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                    </tr>
                                    </tr>
                                    <tr>
                                        <td>Alamat Lengkap</td>
                                        <td>:</td>
                                        <td>
                                            <textarea name="alamat" class="form-control  <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <hr>
                            <div class="text-center">
                                <small class="text-muted fw-bold">Semua pembayaran akan direcord untuk mencegah hal
                                    tidak ingin terjadi</small>
                                <br>
                                <small class="text-muted fw-bold">Your IP Address : <?php echo e($secure['IP']); ?> and User Agent :
                                    <?php echo e($secure['agent']); ?></small>
                            </div>
                            <hr>
                            <input type="text" hidden name="product_id" value="<?php echo e($data->id); ?>">

                            <!-- Checkout Button -->
                            <button type="submit" id="checkout-button" class="btn btn-primary btn-bayar w-100">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Bayar Sekarang
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

</main>


// Ini yang ditambahin

<script>
    // Pastikan harga ada
    const harga = <?php echo json_encode($data->harga); ?>;

    // Fungsi untuk menghitung total
    function updateTotal() {
        const jumlah = document.getElementById('jumlah').value || 1; // Ambil nilai jumlah, jika kosong set 1
        const total = jumlah * harga;
        document.getElementById('total-text').innerText = `Rp ${total.toLocaleString('id-ID')}`;
    }

    // Tambahkan event listener untuk input jumlah
    document.getElementById('jumlah').addEventListener('input', updateTotal);

    // Panggil updateTotal() pertama kali untuk menampilkan total awal
    updateTotal();
</script>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CODINGrevs\CODING\sipentas\pengmas\resources\views/home/cart/index.blade.php ENDPATH**/ ?>