

<?php $__env->startSection('title'); ?>
    Kelola Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- DataTable with Buttons -->
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="head-label text-center">
                    <h5 class="card-title mb-0"><?php echo $__env->yieldContent('title'); ?></h5>
                </div>
                <a class="btn btn-primary" href="<?php echo e(route('admin.product.create')); ?>"><i class="ti ti-plus me-sm-1"></i>
                    Tambah Baru</a>
            </div>
            <div class="card-body">
                <form action="" method="GET">
                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label for="defaultSelect" class="form-label">Filter Mitra</label>
                            <select id="defaultSelect" class="form-select" name="mitra">
                                <option value="">-- Pilih --</option>
                                <?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tani): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tani->id); ?>"><?php echo e($tani->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label for="defaultSelect" class="form-label">Cari Product</label>
                            <input type="text" class="form-control" placeholder="Cari disini" autocomplete="off"
                                name="q">
                        </div>

                        <div class="mb-0 col-12">
                            <div class="row">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-label-primary shadow-sm waves-effect w-100">
                                        Mulai Filter Tabel
                                    </button>
                                </div>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('admin.product.index')); ?>"
                                        class="btn btn-label-danger shadow-sm waves-effect w-100">Reset</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <hr>
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Title</th>
                                <th>Tani</th>
                                <th>Stock</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->tani->title); ?></td>
                                    <td><?php echo e($item->stock); ?> Stock</td>
                                    <td>
                                        <span
                                            class="badge <?php echo e($item->status == 'publish' ? 'bg-label-success' : 'bg-label-danger'); ?> me-1">
                                            <?php echo e($item->status); ?>

                                        </span>
                                    </td>
                                    <td class="d-flex">
                                        <a href="<?php echo e(route('admin.product.edit', $item->id)); ?>"
                                            class="btn btn-icon btn-label-warning waves-effect shadow-sm me-3">
                                            <span class="ti ti-edit"></span>
                                        </a>
                                        <form action="<?php echo e(route('admin.product.destroy', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="btn btn-icon btn-label-danger waves-effect shadow-sm">
                                                <span class="ti ti-trash"></span>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Data Not Found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4 mx-auto pagination justify-content-center">
                        <?php echo $data->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="ajaxModel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modelHeading"></h4>
                </div>
                <div class="modal-body">
                    <form id="productForm" name="productForm" class="form-horizontal">
                        <input type="hidden" name="product_id" id="product_id">
                        <div class="form-group mb-3">
                            <label for="name" class="control-label mb-3">Title</label>
                            <input type="text" class="form-control" id="name" name="name"
                                placeholder="Enter Name" value="" maxlength="50" required="">
                        </div>

                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Save changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pengmas\resources\views/v1/product/index.blade.php ENDPATH**/ ?>