

<?php $__env->startSection('title'); ?>
    Cek Ongkir Pengiriman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section class="auth" style="margin-top: 20px;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-5">
                        <div class="card p-3 rounded-15 shadow-nih">
                            <div class="text-center">
                                <h2>Cek Ongkir</h2>
                                <p class="desc">Cek Harga Pengiriman Kelokasi Anda</p>
                            </div>
                            <hr>
                            <form class="mt-3" method="post" action="<?php echo e(route('ongkir.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">Nama Kota / Kecamatan</label>
                                            <select
                                                class="form-select select2 mb-3 provinsi <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="provinsi" aria-label="Default select example" name="provinsi">
                                            </select>
                                            <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary btn-form mb-3">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <?php if(!empty($data)): ?>
                            <h2 class="mt-4 text-center mb-2">Hasil Ekspedisi</h2>
                            <p class="desc text-center">Berikut Ekspedisi Yang Kami Sediakan</p>
                            <div class="row mt-4">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <div class="card p-3 rounded-15 shadow-nih <?php echo e($key > 0 ? 'mt-3' : null); ?>">
                                            <div class="d-flex">
                                                <div class="icons" style="display:grid;">
                                                    <img src="https://www.hitoko.co.id/blog/wp-content/uploads/2022/12/kenali-joni-jne-untuk-bisnis-1.jpg"
                                                        width="120" height="100" alt="">
                                                    <small
                                                        style="margin-left: 32px;margin-top: 5px;"><?php echo e($item['estimasi']); ?></small>
                                                </div>
                                                <div class="ringkasan">
                                                    <h2 style="font-size: 20px; margin-bottom: 10px;"><?php echo e($item['title']); ?>

                                                    </h2>
                                                    <p class="desc mb-0"><i class="fas fa-truck-loading"></i> Dari Magelang
                                                    </p>
                                                    <p class="desc mb-0"><i class="fas fa-truck"></i> Ke
                                                        <?php echo e($item['tujuan']); ?></p>
                                                    <p class="desc mb-0"><i class="fas fa-money-bill-wave-alt"></i> Harga :
                                                        <?php echo e($item['harga']); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <!-- Styles -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" />
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.full.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            const url = "<?php echo e(route('ongkir')); ?>";

            $('.provinsi').select2({
                theme: 'bootstrap-5',
                ajax: {
                    url: url, // Ganti dengan URL API Anda
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function(response) {
                        // console.log(response);
                        return {
                            results: $.map(response, function(item) {
                                // console.log(item);
                                // return item
                                return {
                                    text: item.text,
                                    id: item.id
                                }
                            })
                        };
                    },
                    cache: true
                },
                minimumInputLength: 3
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pengmas\resources\views/home/ongkir/index.blade.php ENDPATH**/ ?>