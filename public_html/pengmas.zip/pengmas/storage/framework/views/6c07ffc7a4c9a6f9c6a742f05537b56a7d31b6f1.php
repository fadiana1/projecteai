

<?php $__env->startSection('title'); ?>
    Orderan Selesai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- DataTable with Buttons -->
        <div class="card">
            <div class="card-header">
                <div class="head-label text-center">
                    <h5 class="card-title mb-4"><?php echo $__env->yieldContent('title'); ?></h5>
                </div>
            </div>
            <div class="card-body">
                <form action="" method="GET">
                    <div class="row">
                        <div class="mb-3 col-md-2">
                            <label for="defaultSelect" class="form-label">Filter Bulan Ke</label>
                            <input type="text" class="form-control from" placeholder="Cari disini" autocomplete="off"
                                name="from">
                        </div>
                        <div class="mb-3 col-md-2">
                            <label for="defaultSelect" class="form-label">Sampai Bulan Ke</label>
                            <input type="text" class="form-control to" placeholder="Cari disini" autocomplete="off"
                                name="to">
                        </div>
                        <div class="mb-3 col-md-2">
                            <label for="defaultSelect" class="form-label">Filter Tahun</label>
                            <input type="text" class="form-control tahun" placeholder="Cari disini" autocomplete="off"
                                name="tahun">
                        </div>
                        <div class="mb-3 col-md-2">
                            <label for="defaultSelect" class="form-label">Filter Pengiriman</label>
                            <select id="defaultSelect" class="form-select" name="pengiriman">
                                <option value="">-- Pilih --</option>
                                <option value="cod">Cash On Delivery</option>
                                <option value="expedisi">Ekspedisi</option>
                            </select>
                        </div>
                        <div class="mb-3 col-md-4">
                            <label for="defaultSelect" class="form-label">Filter Harga</label>
                            <select id="defaultSelect" class="form-select" name="harga">
                                <option value="">-- Pilih --</option>
                                <option value="asc">Terendah - Tertinggi ( ASC )</option>
                                <option value="desc">Tertinggi - Terendahr ( DESC )</option>
                            </select>
                        </div>

                        <div class="mb-0 col-12">
                            <div class="row">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-label-primary shadow-sm waves-effect w-100">
                                        Export Ke Excel
                                    </button>
                                </div>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('admin.order-selesai')); ?>"
                                        class="btn btn-label-danger shadow-sm waves-effect w-100">Reset</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <hr>
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>INV</th>
                                <th>Product</th>
                                <th>Jumlah</th>
                                <th>Pengiriman</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->inv); ?></td>
                                    <td><?php echo e($item->product->title); ?></td>
                                    <td><?php echo e($item->jumlah); ?></td>
                                    <td><?php echo e($item->pengiriman); ?></td>
                                    <td>
                                        <span class="badge bg-success bg-glow">SELESAI</span>
                                    </td>
                                    <td class="d-flex">
                                        <a href="<?php echo e(route('admin.order-selesai.detail', $item->inv)); ?>"
                                            class="btn btn-success waves-effect shadow-sm me-3">
                                            <span class="ti ti-file me-2"></span> Cetak Inv
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">Data Not Found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4 mx-auto pagination justify-content-center">
                        <?php echo $data->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/css/bootstrap-datepicker.min.css"
        integrity="sha512-34s5cpvaNG3BknEWSuOncX28vz97bRI59UnVtEEpFX536A7BtZSJHsDyFoCl8S7Dt2TPzcrCEoHBGeM4SUBDBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/js/bootstrap-datepicker.min.js"
        integrity="sha512-LsnSViqQyaXpD4mBBdRYeP6sRwJiJveh2ZIbW41EBrNmKxgr/LFZIiWT6yr+nycvhvauz8c2nYMhrP80YhG7Cw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(".from").datepicker({
            format: "mm",
            startView: "months",
            minViewMode: "months",
            orientation: "auto bottom"
        });
        $(".tahun").datepicker({
            format: "yyyy",
            startView: "years",
            minViewMode: "years",
            orientation: "auto bottom"
        });

        $(".to").datepicker({
            format: "mm",
            startView: "months",
            minViewMode: "months",
            orientation: "auto bottom"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pengmas\resources\views/v1/order-selesai/index.blade.php ENDPATH**/ ?>