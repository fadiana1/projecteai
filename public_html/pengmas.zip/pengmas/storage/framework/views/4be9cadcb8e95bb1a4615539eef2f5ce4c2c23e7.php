

<?php $__env->startSection('title'); ?>
    Lacak Pembayaran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section class="auth" style="margin-top: 20px;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-5">
                        <div class="card p-3 rounded-15 shadow-nih">
                            <div class="text-center">
                                <h2>Lacak Order</h2>
                                <p class="desc">Lacak Orderan</p>
                            </div>
                            <hr>
                            <?php if(empty($data)): ?>
                                <form class="mt-3" method="get" action="">
                                    <div class="mb-3">
                                        <label class="form-label">Nomor Invoice</label>
                                        <input type="text"
                                            class="form-control <?php $__errorArgs = ['inv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-center"
                                            name="inv" id="inv" placeholder="#inv1231">
                                        <?php $__errorArgs = ['inv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary btn-form mb-3">Submit</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <img src="https://barcodeapi.org/api/128/<?php echo e($data->inv); ?>"
                                    style=" width: 100%; height: 140px; margin-top: 20px; margin-bottom: 20px;">
                                <table class="table table-striped">
                                    <tbody>
                                        <tr>
                                            <td>Invoice Number</td>
                                            <td>:</td>
                                            <td><?php echo e($data->inv); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Jumlah</td>
                                            <td>:</td>
                                            <td><?php echo e($data->jumlah); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Product</td>
                                            <td>:</td>
                                            <td><?php echo e($data->product->title); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Harga</td>
                                            <td>:</td>
                                            <td>Rp. <?php echo e(number_format($data->harga)); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Transfer Ke</td>
                                            <td>:</td>
                                            <td><?php echo e($data->pembayaran); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Pembayaran</td>
                                            <td>:</td>
                                            <td>
                                                <?php
                                                    $payment = $data->payment;
                                                    switch ($payment) {
                                                        case 'pending':
                                                            # code...
                                                            echo '<span class="badge bg-warning bg-glow">PENDING</span>';
                                                            break;
                                                        case 'aprove':
                                                            # code...
                                                            echo '<span class="badge bg-success bg-glow">Di Setujui</span>';
                                                            break;
                                                        default:
                                                            # code...
                                                            echo '<span class="badge bg-info bg-glow">Tidak Sesuai</span>';
                                                            break;
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Status Order</td>
                                            <td>:</td>
                                            <td>
                                                <?php
                                                    $status = $data->status;
                                                    switch ($status) {
                                                        case 'pending':
                                                            # code...
                                                            echo '<span class="badge bg-danger bg-glow">PENDING</span>';
                                                            break;
                                                        case 'proses':
                                                            # code...
                                                            echo '<span class="badge bg-warning bg-glow">SEDANG PROSES</span>';
                                                            break;
                                                        case 'mengirim':
                                                            # code...
                                                            echo '<span class="badge bg-info bg-glow">Sedang Mengirim</span>';
                                                            break;
                                                        default:
                                                            # code...
                                                            echo '<span class="badge bg-success bg-glow">SELESAI</span>';
                                                            break;
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <a href="<?php echo e(route('lacak')); ?>" style="padding-top:12px; "
                                    class="btn btn-primary btn-form mb-3">Cek Lagi</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipentas\pengmas\resources\views/home/lacak/index.blade.php ENDPATH**/ ?>