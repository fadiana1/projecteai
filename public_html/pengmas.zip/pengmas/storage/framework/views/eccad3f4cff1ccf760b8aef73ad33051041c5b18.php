
<?php $__env->startSection('title'); ?>
    Orders #<?php echo e($data->inv); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    #<?php echo e($data->inv); ?>

                    <?php
                        $status = $data->status;
                        switch ($status) {
                            case 'pending':
                                # code...
                                echo '<span class="badge bg-danger bg-glow">PENDING</span>';
                                break;
                            case 'proses':
                                # code...
                                echo '<span class="badge bg-warning bg-glow">SEDANG PROSES</span>';
                                break;
                            default:
                                # code...
                                echo '<span class="badge bg-info bg-glow">SEDANG PENGIRIMAN</span>';
                                break;
                        }
                    ?>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title text-center">Detail Order</h5>
                <form action="<?php echo e(route('admin.order-masuk.update', $data->inv)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <td>Nama Lengkap</td>
                                <td>:</td>
                                <td>
                                    <?php echo e($data->name); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Nomor Telepon</td>
                                <td>:</td>
                                <td>
                                    <?php echo e($data->phone); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Item Pesanan</td>
                                <td>:</td>
                                <td><?php echo e($data->product->title); ?></td>
                            </tr>
                            <tr>
                                <td>Pembayaran</td>
                                <td>:</td>
                                <td>
                                    <?php echo e($data->pembayaran); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Pengiriman</td>
                                <td>:</td>
                                <td>
                                    <?php echo e($data->pengiriman); ?> Melalui <?php echo e($data->expedisi ?? null); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Jumlah Pesanan</td>
                                <td>:</td>
                                <td><?php echo e($data->jumlah); ?></td>
                            </tr>
                            <tr>
                                <td>Alamat Lengkap</td>
                                <td>:</td>
                                <td>
                                    <?php echo e($data->alamat); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Status Pembayaran</td>
                                <td>:</td>
                                <td class="d-flex">
                                    <select class="form-select <?php $__errorArgs = ['pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-50"
                                        name="pembayaran" id="pembayaran" aria-label="Default select example">
                                        <option <?php echo e($data->payment == 'pending' ? 'selected' : null); ?> value="pending">
                                            Pending</option>
                                        <option <?php echo e($data->payment == 'aprove' ? 'selected' : null); ?> value="aprove">Aprove
                                        </option>
                                        <option <?php echo e($data->payment == 'gagal' ? 'selected' : null); ?> value="gagal">Gagal
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <button type="button"
                                        class="btn btn-primary waves-effect waves-light w-50 ms-2 <?php echo e($data->bukti == null ? 'kosong' : 'muncul'); ?>"
                                        style="border: none;">Lihat
                                        Bukti Pembayaran</button>
                                </td>
                            </tr>
                            <tr>
                                <td>Status Orders</td>
                                <td>:</td>
                                <td>
                                    <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-50" name="status"
                                        id="status" aria-label="Default select example">
                                        <option <?php echo e($data->status == 'pending' ? 'selected' : null); ?> value="pending">
                                            Pending</option>
                                        <option <?php echo e($data->status == 'proses' ? 'selected' : null); ?> value="proses">Proses
                                        </option>
                                        <option <?php echo e($data->status == 'mengirim' ? 'selected' : null); ?> value="mengirim">
                                            Mengirim
                                        </option>
                                        <option <?php echo e($data->status == 'selesai' ? 'selected' : null); ?> value="selesai">
                                            Selesai
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary waves-effect waves-light mt-4 w-100">Update Progress
                        Order</button>
                </form>
            </div>
            <div class="card-footer text-muted">
                <div class="d-flex justify-content-between">
                    Order Date
                    <p><?php echo e($data->created_at); ?></p>
                </div>
            </div>
        </div>
    </div>

    <?php if(!empty($data->bukti)): ?>
        <div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalCenterTitle">Bukti Pembayaran #<?php echo e($data->inv); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="<?php echo e(asset('bukti/' . $data->bukti->image)); ?>" class="img-fluid" alt="">
                        <table class="table table-striped mt-3">
                            <tbody>
                                <tr>
                                    <td>Nama Lengkap</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($data->bukti->name); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Bank Pengirim</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($data->bukti->bank); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Tanggal Pengiriman</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($data->bukti->tanggal); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-secondary waves-effect" data-bs-dismiss="modal">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $(".kosong").click(function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Mohon Maaf',
                    text: 'Pembeli Belum Melakukan Upload Bukti Pembayaran',
                });
            });
        });

        $(document).ready(function() {
            $(".muncul").click(function() {
                $('#modalCenter').modal('show');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pengmas\resources\views/v1/order-masuk/detail.blade.php ENDPATH**/ ?>