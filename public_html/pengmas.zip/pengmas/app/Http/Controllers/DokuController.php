<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\v1\Order;  // Model untuk memperbarui status order
use Illuminate\Support\Facades\Log;


class DokuController extends Controller{
    public function handleCallback(Request $request)
{
    // Mendapatkan data dari DOKU
    $data = $request->all();

    // Log data yang diterima untuk debugging
    Log::info('DOKU Callback Raw Data: ' . json_encode($data));

    // Cek status transaksi dalam response
    if (isset($data['transaction_status'])) {
        $status = $data['transaction_status'];

        // Debugging untuk memastikan data
        Log::info('Transaction Status: ' . $status);

        // Update status order berdasarkan status transaksi
        $order = Order::where('pay_code', $data['pay_code'])->first();
        if ($order) {
            if ($status === 'SUCCESS') {
                $order->status = 'approved'; // Update status menjadi approved
            } elseif ($status === 'FAILED') {
                $order->status = 'failed'; // Update status menjadi failed
            }
            $order->save();
        }
    } else {
        // Jika tidak ada 'transaction_status', log untuk investigasi
        Log::warning('Transaction status not found in callback data');
    }

    // Kirim response sukses ke DOKU
    return redirect()->route('history.index');
    //return response()->json(['status' => 'success'], 200);

    // Redirect ke halaman history (baris ini tidak akan tercapai karena return di atas)
    //return redirect()->route('history.index');
}

}


